import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import RoleNavbar from "./RoleNavbar";
import { useEffect, useState } from "react";
import Translation from "./Data.json";


const { Fragment } = require("react");

function NavBar() {
  const state = useSelector((state) => state);
  console.log("LoggedIn ", state.loggedin);
  console.log("Cart ", state.cart);

  const [language, setLanguage] = useState("1");
  const [content, setContent] = useState({});

  useEffect(() => {
    if (language == "1") {
      setContent(Translation.english);
    } else if (language == "2") {
      setContent(Translation.hindi);
    }
  });

  return (
    <Fragment>
        <div>
            <select value={language} onChange={(e)=>{setLanguage(e.target.value)}}>
            <option>1</option>
                <option>2</option>
            </select>
         
      <div className="clearfix"></div>
      <nav
        className="navbar navbar-expand-lg navbar-dark bg-dark"
        style={{ top: 0, zIndex: "1000" }}
      >
        {" "}
        {/*<Link className="navbar-brand" to="#">Shopping</Link> */}
        <button
          className="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarNavDropdown"
          aria-controls="navbarNavDropdown"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <ul className="navbar-nav ">
          <li className="nav-item ">
            <Link className="nav-link" to="/">
              {content.Home}
            </Link>
          </li>
          <li className="nav navbar-nav ">
            <Link className="nav-link" to="/About">
              {content.About}
            </Link>
          </li>
        </ul>
        &nbsp;&nbsp; &nbsp;&nbsp;
        <RoleNavbar isLoggedIn={state.loggedin.IsLoggedIn} />
      </nav>
      
      </div>
    </Fragment>
  );
}

export default NavBar;
