import React from "react";
import web1 from "../img/footer.png";

function About() {
  return (
    <div>
      <img src={web1} class="d-block w-100" alt="..." />
    </div>
  );
}

export default About;
