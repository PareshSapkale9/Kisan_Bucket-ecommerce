import React from "react";
import web1 from "../img/about.png";

function About() {
  return (
    <div>
      <div class="container-fluid">
        <img src={web1} class="d-block w-100" alt="..." />
        <div className="clearfix"></div>
      </div>
    </div>
  );
}
export default About;
