import "../App.css";
import { useSelector } from "react-redux";
import web1 from "../img/logo p.png";

function Header() {
  const state = useSelector((state) => state);
  console.log("Header ", state.loggedin.Username);
  return (
    <div>
      <div className="jumbotron p-4 mb-1 center rounded-0 text-white ">
        {/* <img src={'public\assets\logo4.png'} style={{width:"150px"}} className="float-left"/> */}
        {state.loggedin.IsLoggedIn ? (
          <>
            {/* <h5 className="float-right">{state.loggedin.Role}</h5>  */}
            <link
              href="https://fonts.googleapis.com/css2?family=ABeeZee&display=swap"
              rel="stylesheet"
              type="text/css"
            ></link>
            <h5 className="float-right" id="role">
              Welcome
              <br /> Name: {state.loggedin.Username}
              <br /> Role: {state.loggedin.Role} <br />
            </h5>{" "}
          </>
        ) : (
          ""
        )}
        <a class="navbar-brand">
          <img width="250" src={web1} class="d-block w-100" className="w-100" />
        </a>

        {/* <h3 className="">KISSAN BUCKET</h3> */}
        <div className="clearfix"></div>
      </div>
    </div>
  );
}

export default Header;
